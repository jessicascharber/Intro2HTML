function displaymessage()
{
  //var r=Math.random();
  //if (r>0.5 && r<0.7){
    alert("You are the lucky winner! Give coupon code, luckyTen, for %10 off your rental price!");
//   }
//  else {
    //  alert("Sorry, you did not win this time. Better luck next time!");
  //}
}
/*function show_confirm()
{
var c=confirm("Click here to see if you're the lucky winner of a coupon!");
if (c==true)  {
  alert("You pressed OK!");
}
  var r=Math.random();
  if (r>0.5 && r<0.7){
    document.write("<b>You are the lucky winner!<b>");
    document.write("Give coupon code, luckyTen, for %10 off your rental price!");
   }
  else {
    document.write("Sorry, better luck next time.");
   }
else {
  document.write(" ");
}*/
//}
/*else
  {
  alert("You pressed Cancel!");
}
}*/

/*var r=Math.random();

if (r>0.5 && r<0.7){
  document.write("<b>You are the lucky winner!<b>")
  document.write("Give coupon code, luckyTen, for %10 off your rental price!")
}
else {
  document.write("Sorry, better luck next time.")
} */
