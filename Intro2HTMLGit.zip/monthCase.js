// Monthly Case Structure
      var d = new Date();
      theMonth=d.getMonth();
      switch (theMonth)
      {
      case 0:
        document.write("<b>The current weekly rate for January is $1000.</b>");
        break;
      case 1:
        document.write("<b>The current weekly rate for February is $1000.</b>");
        break;
      case 2:
        document.write("<b>The current weekly rate for March is $1000.</b>");
        break;
      case 3:
          document.write("<b>The current weekly rate for April is $1500.</b>");
          break;
      case 4:
          document.write("<b>The current weekly rate for May is $2000.</b>");
          break;
      case 5:
          document.write("<b>The current weekly rate for June is $2000.</b>");
          break;
      case 6:
         document.write("<b>The current weekly rate for July is $2000.</b>");
         break;
      case 7:
         document.write("<b>The current weekly rate for August is $2000.</b>");
         break;
      case 8:
         document.write("<b>The current weekly rate for September is $1500.</b>");
         break;
      case 9:
         document.write("<b>The current weekly rate for October is $1000.</b>");
         break;
      case 10:
         document.write("<b>The current weekly rate for November is $1000.</b>");
         break;
      case 11:
         document.write("<b>The current weekly rate for December is $1000.</b>");
         break;
      }
